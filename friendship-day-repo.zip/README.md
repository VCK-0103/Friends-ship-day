# Friendship Day — Transmission 08.02

A single-page, cinematic, futuristic tribute site for Friendship Day (August 2).

Friends are rendered as glowing motion-capture rigs (joint nodes + limb lines,
dual-tone cyan/pink rim light) arranged in a dynamic hero collage with
mouse-parallax depth, cinema letterbox bars, film grain, and a scene rail of
six friendship "moves." Includes a live countdown to the next Aug 2 and an
interactive "transmission" card composer you can beam and download as a PNG.

## View it

Just open `index.html` in any modern browser — no build step, no dependencies
beyond Google Fonts (loaded via CDN link).

Or serve it locally:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Live demo (GitHub Pages)

Once pushed, enable Pages in **Settings → Pages → Source: `main` branch, `/root`**,
and the site will be live at:

```
https://<your-username>.github.io/<repo-name>/
```

## Structure

```
.
├── index.html   # entire site — markup, styles, and JS in one file
└── README.md
```

## Customize

- Scene poses & captions: edit the `SCENES` array in the `<script>` block.
- Hero collage layout: edit the `heroLayout` array.
- Colors/fonts: CSS custom properties at the top of `<style>`.
